/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package api.catalog.mycatalog;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import org.json.JSONObject;
/**
 *
 * @author lizst
 */
public class MyCatalog {
    private static int ITEM_REQUEST_LIMIT = 25;
    
    public static void main(String[] args) throws IOException, InterruptedException{
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://openapi.etsy.com/v2/listings/active?api_key=pzm9kr33wye2gmv9fy2h4g64&limit="+ITEM_REQUEST_LIMIT))
                .method("GET", HttpRequest.BodyPublishers.noBody())
                .build();
        HttpResponse<String> response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
        JSONObject jsonResponse = new JSONObject(response.body());
        parse(jsonResponse);
    }
    
    public static String parse(JSONObject responseB){
        for(int i = 0; i < ITEM_REQUEST_LIMIT; i++) {
            String title = responseB.getJSONArray("results").getJSONObject(i).getString("title");
            String description = responseB.getJSONArray("results").getJSONObject(i).getString("description");
            String price = responseB.getJSONArray("results").getJSONObject(i).getString("price");
            System.out.println(title + "\n" + description + ":" + "\n" + price);
        }
        return null;
    }
}
